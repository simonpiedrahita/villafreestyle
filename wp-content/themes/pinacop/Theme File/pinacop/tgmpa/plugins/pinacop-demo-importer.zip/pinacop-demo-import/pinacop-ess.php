<?php
/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://www.gpthemes.co/
 * @since             1.0.0
 * @package           Pinacop Ess
 *
 * @wordpress-plugin
 * Plugin Name:       Pinacop Demo Impoter
 * Plugin URI:        https://www.gpthemes.co/products/devent-wordpress
 * Description:       This plugin is developed only for the Pinacop theme by Gp Theme. Please keep active while you are using the devent theme otherwise please de-active this because the plugin is useless with another theme.
 * Version:           1.0.0
 * Author:            GP Themes
 * Author URI:        https://www.gpthemes.co/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       pinacop-ess
 * Domain Path:       /languages
 */

/**
 * DT Importer : https://github.com/AminulBD/dt-demo-importer
 */
/**
 * Importer constants
 */
define( 'DT_IMPORTER_VER' , '1.0.1' );
define( 'DT_IMPORTER_DIR' , plugin_dir_path( __FILE__ ) );
define( 'DT_IMPORTER_URI' , plugin_dir_url( __FILE__ ) );
define( 'DT_IMPORTER_CONTENT_DIR' , DT_IMPORTER_DIR . '/demos/' );
define( 'DT_IMPORTER_CONTENT_URI' , DT_IMPORTER_URI . '/demos/' );

/**
 * Scripts and styles for admin
 */
function dt_importer_enqueue_scripts() {

	wp_enqueue_script( 'dt-importer', DT_IMPORTER_URI . '/assets/js/dt-importer.js', array( 'jquery' ), DT_IMPORTER_VER, true);
	wp_enqueue_style( 'dt-importer-css', DT_IMPORTER_URI . '/assets/css/dt-importer.css', null, DT_IMPORTER_VER);

	wp_localize_script( 'dt-importer', 'dt_importer', array( 'ajax_url' => admin_url( 'admin-ajax.php' ) ) );
}

add_action( 'admin_enqueue_scripts', 'dt_importer_enqueue_scripts' );


/**
 * Load Importer
 */
require_once DT_IMPORTER_DIR . '/classes/abstract.class.php';
require_once DT_IMPORTER_DIR . '/classes/importer.class.php';

/**
 * Initialize DT Importer
 */
$settings 	= array(
	'menu_parent'	=> 'tools.php',
	'menu_title'	=> esc_html__('Demo Importer', 'pinacop-ess'),
	'menu_type'		=> 'add_submenu_page',
	'menu_slug'		=> 'pinacop-importer',
);

$items 		= array(

	'home' => array(
		'title'			=> esc_html__('Home Main', 'pinacop-ess'),
		'preview_url'	=> esc_url( 'http://wp.gpthemes.co/pinacop/' ),   
		'front_page'	=> 'Home Creative Business',
		'blog_page'		=> 'Blog',
		'menus'			=> array(			
			'main_menu'				=> 'Primary Menu',
			'side_menu'				=> 'Mobile Menu'	
			
		),
	),

	'agency' => array(
		'title'			=> esc_html__('Home Agency', 'pinacop-ess'),
		'preview_url'	=> esc_url( 'http://wp.demo.gpthemes.co/pinacop/agency/' ),   
		'front_page'	=> 'Home Agency',
		'blog_page'		=> 'Blog',
		'menus'			=> array(			
			'main_menu'				=> 'Primary Menu',
			'side_menu'				=> 'Mobile Menu'	
			
		),
	),

	'business' => array(
		'title'			=> esc_html__('Business', 'pinacop-ess'),
		'preview_url'	=> esc_url( 'http://wp.demo.gpthemes.co/pinacop/business/' ),   
		'front_page'	=> 'Home Business',
		'blog_page'		=> 'Blog',
		'menus'			=> array(			
			'main_menu'				=> 'Primary Menu',	
			'side_menu'				=> 'Mobile Menu'
			
		)
	),

	'app' => array(
		'title'			=> esc_html__('Pinacop App', 'pinacop-ess'),
		'preview_url'	=> esc_url( 'http://wp.demo.gpthemes.co/pinacop/app/' ),   
		'front_page'	=> 'Pinacop App',
		'blog_page'		=> 'Blog',
		'menus'			=> array(			
			'main_menu'				=> 'Primary Menu',
			'side_menu'				=> 'Mobile Menu'	
			
		)
	),

	'corporate' => array(
		'title'			=> esc_html__('Home Corporate', 'pinacop-ess'),
		'preview_url'	=> esc_url( 'http://wp.demo.gpthemes.co/pinacop/corporate/' ),   
		'front_page'	=> 'Home Corporate',
		'blog_page'		=> 'Blog',
		'menus'			=> array(			
			'main_menu'				=> 'Primary Menu',
			'side_menu'				=> 'Mobile Menu'	
			
		)
	),

	'conferance' => array(
		'title'			=> esc_html__('Home Conferance', 'pinacop-ess'),
		'preview_url'	=> esc_url( 'http://wp.demo.gpthemes.co/pinacop/confarance/' ),   
		'front_page'	=> 'Home Conference',
		'blog_page'		=> 'Blog',
		'menus'			=> array(			
			'main_menu'				=> 'Primary Menu',
			'side_menu'				=> 'Mobile Menu'	
			
		)
	)	
);


DT_Demo_Importer::instance( $settings, $items );